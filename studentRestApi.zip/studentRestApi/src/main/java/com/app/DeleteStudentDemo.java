package com.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.controller.studentController;

public class DeleteStudentDemo {
	public static void main(String arg[]){
		// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");

		studentController studentcontroller = (studentController) context.getBean("studentcontroller");
		
		studentcontroller.deleteStudent(1);
		


}
}
