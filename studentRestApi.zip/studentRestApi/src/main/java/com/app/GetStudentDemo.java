package com.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.controller.studentController;

import com.domain.Student;

public class GetStudentDemo {
	public static void main(String arg[]){
	// loading the definitions from the given XML file
	ApplicationContext context = new ClassPathXmlApplicationContext(
			"applicationContext.xml");

	studentController controller = (studentController) context.getBean("studentcontroller");
	
	Student customer = controller.getStudentDetails(1234);
	
	System.out.println("Student Id "+customer.getId());
	
	System.out.println("Student Name "+customer.getName());
	System.out.println("Student Age "+customer.getAge());


}
}
