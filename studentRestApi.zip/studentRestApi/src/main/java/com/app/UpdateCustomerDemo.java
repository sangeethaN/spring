package com.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.controller.*;
import com.domain.*;

public class UpdateCustomerDemo {
	public static void main(String arg[]){
		// loading the definitions from the given XML file
			ApplicationContext context = new ClassPathXmlApplicationContext(
					"applicationContext.xml");

			studentController controller = (studentController) context.getBean("controller");
			
			Student customer = new Student();
			customer.setId(12412);
			customer.setName("aaaa");
			
			
			controller.updateStudent(customer);
	
	
	}
}
