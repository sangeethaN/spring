package com.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.controller.studentController;
import com.domain.Student;


public class InsertStudentDemo {

	public static void main(String arg[]){
		// loading the definitions from the given XML file
			ApplicationContext context = new ClassPathXmlApplicationContext(
					"applicationContext.xml");

			studentController controller = (studentController) context.getBean("studentcontroller");
			
			Student customer = new Student();
			customer.setId(3388);
			customer.setName("sss");
			customer.setAge(22);
			
			
			controller.createStudent(customer);

		

	}
}
