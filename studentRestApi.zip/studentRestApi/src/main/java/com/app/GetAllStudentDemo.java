package com.app;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.controller.studentController;
import com.domain.Student;


public class GetAllStudentDemo {
public static void main(String arg[]){
		
		// loading the definitions from the given XML file
				ApplicationContext context = new ClassPathXmlApplicationContext(
						"applicationContext.xml");
		 
				studentController studentcontroller = (studentController) context.getBean("studentcontroller");
				
				//Customer customer = new Customer();
				
				
				//controller.createCustomer(customer);
				
				List studentList = studentcontroller.getAllStudent();
				
				Iterator studentListIterator = studentList.iterator();
				
				while(studentListIterator.hasNext()){
					
					Student student = (Student)studentListIterator.next();
							
					System.out.println("Student Id "+student.getId());
					
					System.out.println("Student Name "+student.getName());
					System.out.println("Student age "+student.getAge());
					
					
				}
				
				
			}
}
