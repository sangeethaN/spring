package com.Dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.domain.Student;



public class StudentDao {
@Autowired
	private DataSource dataSource;
	
	   private JdbcTemplate jdbcTemplateObject;
	   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }
	
	   public void createStudent(Student student){
			
		      String sql ="insert into StudentMaster values ("+student.getId()+",'"+student.getName()+"',"+student.getAge()+")";
		      System.out.println("sql "+sql);			

		      jdbcTemplateObject.update(sql);
					
					
		   }
			
			
			public void updateStudent(Student student){
				
				String sql="update StudentMaster set name='" +student.getName()+"' where id=" + student.getId();
				 System.out.println("sql "+sql);	
				 
				 jdbcTemplateObject.update(sql);
			}
			
					
		public void deleteStudent(int Id){
				
				String sql="delete from StudentMaster where id="+Id;
				 System.out.println("sql "+sql);	
				 
				 jdbcTemplateObject.update(sql);
			}

				
			
			public List getAllStudent(){
				
				List StudentList = null;
				String sql="select * from StudentMaster";
				StudentList = jdbcTemplateObject.query(sql, new Object[]{}, new StudentMapper());
			      
			    return 	StudentList;
			    
			  }
				
					
			

		 public Student getStudentDetails(int Id) {
			 
		String sql = "select * from StudentMaster where id= ?";

		Student student=jdbcTemplateObject.queryForObject(sql, new Object[]{Id}, new StudentMapper());

		return student;
		}
	
	
}
