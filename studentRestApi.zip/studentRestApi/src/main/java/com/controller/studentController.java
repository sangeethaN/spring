package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.Dao.StudentDao;
import com.domain.Student;


@Controller 
public class studentController {
	
	@Autowired
	private StudentDao studentDao;
	
	
	public void createStudent(Student student){
		System.out.println("inside CustomerController createCustomer");
		
		studentDao.createStudent(student);
		
		
	}
	
	public Student getStudentDetails(int Id){
		
	    Student student = null;
	    student= studentDao.getStudentDetails(Id);
		return student;
	}
	
	public void updateStudent(Student student){
		
		studentDao.updateStudent(student);
		
	}
	
	public void deleteStudent(int Id){
		
		studentDao.deleteStudent(Id);
		
	}
	
	@RequestMapping(value="/tests", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})
	public List getAllStudent(){
		
		System.out.println("success");
		List StudentList = null;
		
		
		StudentList = studentDao.getAllStudent();
		return StudentList;
	}
	
	
		
	

}
